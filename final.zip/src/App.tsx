import { Route, Routes } from 'react-router-dom'
import AppShell from './components/AppShell'
import ProtectedRoute from './components/ProtectedRoute'
import ConfigMissing from './pages/ConfigMissing'
import Placeholder from './pages/Placeholder'
import Login from './pages/Login'
import Register from './pages/Register'
import ForgotPassword from './pages/ForgotPassword'
import ResetPassword from './pages/ResetPassword'
import FamilyPage from './pages/Family'
import JoinFamily from './pages/JoinFamily'
import Profile from './pages/Profile'
import MemberDetail from './pages/MemberDetail'
import HistoryPage from './pages/History'
import Privacy from './pages/Privacy'
import SosPage from './pages/Sos'
import SosDetail from './pages/SosDetail'
import NotificationsPage from './pages/Notifications'
import PlacesPage from './pages/Places'
import ChatPage from './pages/Chat'
import Home from './pages/Home'
import MapPage from './pages/MapPage'
import { isConfigured } from './lib/supabase'

export default function App() {
  if (!isConfigured) return <ConfigMissing />

  return (
    <Routes>
      <Route path="/masuk" element={<Login />} />
      <Route path="/daftar" element={<Register />} />
      <Route path="/lupa-sandi" element={<ForgotPassword />} />
      <Route path="/atur-ulang" element={<ResetPassword />} />
      <Route element={<ProtectedRoute />}>
        <Route element={<AppShell />}>
          <Route index element={<Home />} />
          <Route path="peta" element={<MapPage />} />
          <Route path="keluarga" element={<FamilyPage />} />
          <Route path="gabung/:token" element={<JoinFamily />} />
          <Route path="riwayat" element={<HistoryPage />} />
          <Route path="anggota/:id" element={<MemberDetail />} />
          <Route path="privasi" element={<Privacy />} />
          <Route path="sos" element={<SosPage />} />
          <Route path="sos/:id" element={<SosDetail />} />
          <Route path="notifikasi" element={<NotificationsPage />} />
          <Route path="tempat" element={<PlacesPage />} />
          <Route path="chat" element={<ChatPage />} />
          <Route path="profil" element={<Profile />} />
        </Route>
      </Route>
      <Route path="*" element={<Placeholder title="Halaman tidak ditemukan" stage={1} />} />
    </Routes>
  )
}
