# Panduan pasang Family Tracker (paket akhir)

Tujuan: hanya SATU kali build di Netlify. Semua pengecekan dilakukan di Codespaces dulu.

## 1. Unggah ke cabang `dev` (bukan main)
GitHub repo > Add file > Upload files > pilih `final.zip` > pilih **Create a new branch** (nama `dev`) > Commit.
Netlify hanya membangun cabang `main`, jadi langkah ini tidak memakai kredit.

## 2. Cek build di Codespaces
```
git fetch origin && git checkout dev
unzip -o final.zip && rm final.zip
npm install && npm run build
```
Harus berakhir dengan tulisan `built in`. Jika error, kirim fotonya, perbaiki dulu.

## 3. Buat kunci push
```
npx web-push generate-vapid-keys
```
Catat Public Key dan Private Key.

## 4. Supabase: jalankan SQL
Buka `supabase/RUN_ME_ALL.sql` di editor Codespaces > Select All > Copy > Supabase SQL Editor > New query > Paste > Run.

## 5. Supabase: Edge Functions
Edge Functions > Secrets, tambahkan:
- `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY` (dari langkah 3)
- `VAPID_SUBJECT` = `mailto:emailmu@contoh.com`
- `WEBHOOK_SECRET` = teks acak panjang buatanmu

Edge Functions > Deploy a new function > Via Editor:
- nama `send-push`, tempel isi `supabase/functions/send-push/index.ts`
- nama `delete-account`, tempel isi `supabase/functions/delete-account/index.ts`

## 6. Supabase: Database Webhook
Integrations > Database Webhooks > Create:
- Table `notifications`, Events: Insert
- Type: Supabase Edge Functions, function `send-push`, method POST
- Tambah HTTP header `x-webhook-secret` berisi nilai WEBHOOK_SECRET

## 7. Netlify: variabel
Tambahkan `VITE_VAPID_PUBLIC_KEY` = Public Key dari langkah 3.

## 8. Rilis (satu build)
```
git checkout main && git merge dev && git push
```

## 9. Uji push
Buka situs di HP, pasang ke Layar Utama, Notifikasi > nyalakan "Notifikasi di perangkat ini".
Dari akun lain, kirim SOS atau chat. Notifikasi harus masuk walau aplikasi ditutup.

## 10. APK Android (opsional, eksperimental)
GitHub > tab Actions > Build APK Android > Run workflow. Setelah selesai, unduh artifact `family-tracker-apk`, ekstrak, pasang `app-debug.apk` (izinkan "instal dari sumber tidak dikenal"). Saat pertama dibuka, pilih izin lokasi **Selalu izinkan**.
